
<?php $__env->startSection('title','Lista de Estudantes'); ?>

<?php $__env->startSection('content'); ?>
<h1>Lista de Estudantes</h1>
<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Nome</th>
            <th scope="col">CPF</th>
            <th scope="col">Aniversario</th>
            <th scope="col">Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $estudantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudantes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($estudantes ->id); ?></th>
            <th scope="row">
                <a href="<?php echo e(route('estudantes.show', $estudantes )); ?>"><?php echo e($estudantes->nome); ?></a>
            </th>
            <th scope="row"><?php echo e(substr($estudantes->cpf, 0, 3) . '.' . substr($estudantes->cpf, 3, 3) . '.' . substr($estudantes->cpf, 6, 3) . '-' . substr($estudantes->cpf, 9, 2)); ?></th>
            <th scope="row"><?php echo e(date('d/m/Y', strtotime($estudantes->nascimento))); ?></th>
            <th>
            
                <a class="btn btn-primary" href="<?php echo e(route('estudantes.edit', $estudantes)); ?>">Editar</a>

            <form action="<?php echo e(route('estudantes.destroy', $estudantes)); ?>"
            method="POST"
            >
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>

            <button  

              class="btn btn-danger"
              type="submit"
              onclick="return confirm('Tem certeza que quer apagar?')" 
              > 
              
              APAGAR

            </button>
             </form>
            </th>
           
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a class="btn btn-success" href="<?php echo e(route('estudantes.create')); ?>">Novo Estudantes</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projetos-Gazin\LARAVEL\crud_estudantes\resources\views/estudantes/index.blade.php ENDPATH**/ ?>