
<?php $__env->startSection('title', 'Adicionar Novo Estudante'); ?>
<?php $__env->startSection('content'); ?>

    <h1>Novo Estudante</h1>

    <form action="<?php echo e(route('estudantes.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" name="nome" id="nome" placeholder="Digite o nome" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="cpf" class="form-label">CPF</label>
            <input type="text" name="cpf" id="cpf" placeholder="Digite seu CPF" class="form-control" required>
        </div>
        <div class="mb-3">
           <label for="nascimento">Coloque sua data de Nascimento:</label>
           <input type="date" name="nascimento" id="nascimento" placeholder="Preencha sua nascimento" required>
        </div>
         <button class="btn btn-success mb-3" type="submit"> Enviar </button>
         <a class="btn btn-secondary mb-3" href="<?php echo e(route('estudantes.index')); ?>">Voltar para lista de Estudantes</a>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muril\Desktop\trabalho2\resources\views/estudantes/create.blade.php ENDPATH**/ ?>