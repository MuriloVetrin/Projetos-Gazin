
<?php $__env->startSection('title','Detalhes do estudante'); ?>

<?php $__env->startSection('content'); ?>

<div class="card" style="width: 18rem;">
    <div class="card-header">
        <?php echo e($estudantes->nome); ?>

    </div>
    <div class="card-body">
        <p class="card-text"><strong>ID: </strong><?php echo e($estudantes->id); ?></p>
        <p class="card-text"><strong>Nome: </strong><?php echo e($estudantes->nome); ?></p>
        <p class="card-text"><strong>CPF: </strong><?php echo e(substr($estudantes->cpf, 0, 3) . '.' . substr($estudantes->cpf, 3, 3) . '.' . substr($estudantes->cpf, 6, 3) . '-' . substr($estudantes->cpf, 9, 2)); ?></p>
        <p class="card-text"><strong>Data de Nascimento: </strong><?php echo e(date('d/m/Y', strtotime($estudantes->nascimento))); ?></p>
        <br>
        <a href="<?php echo e(route('estudantes.index')); ?>" class="btn btn-success">Voltar á lista de estudantes</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muril\Desktop\trabalho2\resources\views/estudantes/show.blade.php ENDPATH**/ ?>