
<?php $__env->startSection('title', 'Editar Estudante'); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('estudantes.update', $estudantes)); ?>" method="POST">
         <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" name="nome" id="nome" placeholder="Digite o nome" value="<?php echo e($estudantes->nome); ?>"
                class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="cpf" class="form-label">CPF</label>
            <input type="text" name="cpf" id="cpf" placeholder="Digite o seu CPF"
                value="<?php echo e($estudantes->cpf); ?>" class="form-control" required>
        </div>
        <div class="mb-3">
           <label for="nascimento">Coloque sua data de Nascimento:</label>
           <input type="date" name="nascimento" id="nascimento" placeholder="Preencha sua data de nascimento" required>
        </div>
        <button class="btn btn-success mb-3" type="submit"> Enviar </button>
        <a class="btn btn-secondary mb-3" href="<?php echo e(route('estudantes.index')); ?>">Voltar para lista de estudantes</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muril\Documents\trabalho-laravel-2\trabalho2\resources\views/estudantes/edit.blade.php ENDPATH**/ ?>